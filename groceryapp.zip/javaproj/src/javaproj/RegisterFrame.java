package javaproj;



import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class RegisterFrame extends JFrame {
    private UserService userService;

    public RegisterFrame(UserService userService) {
        this.userService = userService;
        setTitle("Register");
        setSize(400, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel panel = new JPanel();
        panel.setLayout(null);
        panel.setBackground(new Color(255, 255, 204)); // Light yellow background

        JLabel userLabel = new JLabel("Username:");
        userLabel.setBounds(10, 20, 80, 25);
        panel.add(userLabel);

        JTextField userText = new JTextField(20);
        userText.setBounds(100, 20, 165, 25);
        panel.add(userText);

        JLabel passwordLabel = new JLabel("Password:");
        passwordLabel.setBounds(10, 50, 80, 25);
        panel.add(passwordLabel);

        JPasswordField passwordText = new JPasswordField(20);
        passwordText.setBounds(100, 50, 165, 25);
        panel.add(passwordText);

        JLabel retypePasswordLabel = new JLabel("Retype Password:");
        retypePasswordLabel.setBounds(10, 80, 120, 25);
        panel.add(retypePasswordLabel);

        JPasswordField retypePasswordText = new JPasswordField(20);
        retypePasswordText.setBounds(140, 80, 125, 25);
        panel.add(retypePasswordText);

        JLabel ageLabel = new JLabel("Age:");
        ageLabel.setBounds(10, 110, 80, 25);
        panel.add(ageLabel);

        JTextField ageText = new JTextField(20);
        ageText.setBounds(100, 110, 165, 25);
        panel.add(ageText);

        JLabel contactLabel = new JLabel("Contact:");
        contactLabel.setBounds(10, 140, 80, 25);
        panel.add(contactLabel);

        JTextField contactText = new JTextField(20);
        contactText.setBounds(100, 140, 165, 25);
        panel.add(contactText);

        JLabel emailLabel = new JLabel("Email:");
        emailLabel.setBounds(10, 170, 80, 25);
        panel.add(emailLabel);

        JTextField emailText = new JTextField(20);
        emailText.setBounds(100, 170, 165, 25);
        panel.add(emailText);

        JLabel genderLabel = new JLabel("Gender:");
        genderLabel.setBounds(10, 200, 80, 25);
        panel.add(genderLabel);

        String[] genders = {"Male", "Female", "Other"};
        JComboBox<String> genderComboBox = new JComboBox<>(genders);
        genderComboBox.setBounds(100, 200, 165, 25);
        panel.add(genderComboBox);

        JButton registerButton = new JButton("Register");
        registerButton.setBounds(10, 240, 80, 25);
        panel.add(registerButton);

        registerButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String username = userText.getText();
                String password = new String(passwordText.getPassword());
                String retypePassword = new String(retypePasswordText.getPassword());
                int age = Integer.parseInt(ageText.getText());
                String contact = contactText.getText();
                String email = emailText.getText();
                String gender = (String) genderComboBox.getSelectedItem();

                // Check if passwords match
                if (!password.equals(retypePassword)) {
                    JOptionPane.showMessageDialog(null, "Passwords do not match.");
                    return;
                }

                if (userService.registerUser (username, password, age, contact, email, gender)) {
                    JOptionPane.showMessageDialog(null, "Registration successful!");
                    dispose(); // Close the registration frame
                } else {
                    JOptionPane.showMessageDialog(null, "Registration failed. Username may already exist.");
                }
            }
        });

        add(panel);
    }
}
